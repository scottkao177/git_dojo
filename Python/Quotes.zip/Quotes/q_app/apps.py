from django.apps import AppConfig


class QAppConfig(AppConfig):
    name = 'q_app'
