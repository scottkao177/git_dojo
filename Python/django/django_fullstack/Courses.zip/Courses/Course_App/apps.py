from django.apps import AppConfig


class CourseAppConfig(AppConfig):
    name = 'Course_App'
